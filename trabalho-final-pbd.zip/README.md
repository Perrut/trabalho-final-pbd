# trabalho-final-pbd

# Enunciado

Escolha um domínio de seu interesse: Campeonato Brasileiro

Entregas

01. Uma descrição do cenário com regras, pessoas, objetos, etc. envolvidos no domínio: https://docs.google.com/document/d/1l-3QEu6bF7eJXGGuHWl7L2gJunBZA9fUqzds_CsjDaI/edit?usp=sharing

02. O modelo conceitual do cenário definido: pelo menos 15 entidades

03. O projeto lógico derivado

04. O script de criação de tabelas

05. Pelo menos 3 visões sobre o esquema

06. Pelo menos 3 triggers

07. Pelo menos 5 stored procedures

08. 20 consultas sobre o esquema
   pelo menos 5 com funções de agregação
   
09. Índices para otimizar as consultas

10. Pelo menos uma tabela deve ser fragmentada
